# Jednostavna aplikacija za ponudu i potraznju prevoza

# Za html i css koristen je bootstrap 3. 
# Tema sa html elementima se nalazi na linku https://bootswatch.com/3/sandstone/

